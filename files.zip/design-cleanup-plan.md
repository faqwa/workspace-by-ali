# Design & Styling Cleanup Plan

## Problems Identified

1. **DaisyUI Configuration Issue**
   - `themes: false` disables DaisyUI's theming but component classes still expect theme variables
   - Custom colors using CSS variables don't integrate with DaisyUI properly
   
2. **Multiple Styling Systems**
   - Custom CSS variables (--personal-primary, --commons-primary)
   - Tailwind utility classes
   - DaisyUI component classes
   - Custom button/form styles
   
3. **Inconsistent Spacing**
   - Custom --space- variables
   - Tailwind spacing (p-4, m-6, etc.)
   - Hard-coded pixel values

4. **Color System Conflicts**
   - CSS variables referencing themselves (circular)
   - DaisyUI expects specific color names (primary, secondary, etc.)
   - Custom brand colors not mapped to DaisyUI system

## Solution: Simplified Modern Design System

### Approach: Pure Tailwind + Minimal DaisyUI

**Strategy:**
1. Remove DaisyUI completely OR configure it properly with custom themes
2. Use Tailwind's built-in theming with CSS variables
3. Create consistent component patterns
4. Simplify the color system

### Option A: Remove DaisyUI (Recommended for Clean Start)

**Pros:**
- Complete control over styling
- No theme conflicts
- Smaller bundle size
- Faster development with pure Tailwind

**Cons:**
- Need to rebuild some components
- No pre-built component classes

### Option B: Configure DaisyUI Properly

**Pros:**
- Keep existing component structure
- Pre-built accessible components
- Faster for forms, cards, buttons

**Cons:**
- Must create custom theme
- More configuration complexity
- Larger bundle size

## Recommended Implementation (Option A)

### Step 1: Update tailwind.config.mjs
```js
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        // Personal Workspace (Green)
        personal: {
          50: '#f0fdf4',
          100: '#dcfce7',
          200: '#bbf7d0',
          300: '#86efac',
          400: '#4ade80',
          500: '#22c55e',  // Primary
          600: '#16a34a',  // Hover
          700: '#15803d',
          800: '#166534',
          900: '#14532d',
        },
        // Commons Workspace (Blue)
        commons: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',  // Primary
          600: '#2563eb',  // Hover
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
        // Semantic colors
        success: '#10b981',
        warning: '#f59e0b',
        error: '#ef4444',
        info: '#3b82f6',
      },
    },
  },
  plugins: [],
}
```

### Step 2: Simplified global.css
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --personal-primary: #22c55e;
    --commons-primary: #3b82f6;
  }
  
  body {
    @apply bg-gray-50 text-gray-900;
  }
  
  [data-theme="dark"] body {
    @apply bg-gray-900 text-gray-100;
  }
}

@layer components {
  /* Button Components */
  .btn {
    @apply px-4 py-2 rounded-lg font-medium transition-all duration-200;
    @apply hover:shadow-md active:scale-95;
  }
  
  .btn-personal {
    @apply bg-personal-500 text-white;
    @apply hover:bg-personal-600;
  }
  
  .btn-commons {
    @apply bg-commons-500 text-white;
    @apply hover:bg-commons-600;
  }
  
  /* Card Components */
  .card {
    @apply bg-white rounded-xl shadow-sm border border-gray-200;
    @apply hover:shadow-md transition-shadow;
  }
  
  [data-theme="dark"] .card {
    @apply bg-gray-800 border-gray-700;
  }
  
  /* Form Components */
  .input {
    @apply w-full px-4 py-2 rounded-lg border border-gray-300;
    @apply focus:outline-none focus:ring-2 focus:ring-personal-500 focus:border-transparent;
    @apply transition-all;
  }
  
  .input-error {
    @apply border-red-500 focus:ring-red-500;
  }
}
```

### Step 3: Component Migration Examples

**Before (DaisyUI):**
```html
<button class="btn btn-primary">Click me</button>
```

**After (Pure Tailwind):**
```html
<button class="btn btn-personal">Click me</button>
```

### Step 4: Remove Unused CSS

Delete or comment out:
- Complex spacing variables
- DaisyUI-specific overrides
- Duplicate color definitions
- Custom component styles that conflict

## Implementation Steps

1. ✅ Backup current styles
2. ✅ Update tailwind.config.mjs
3. ✅ Simplify global.css
4. ✅ Create new component classes
5. ✅ Update all components to use new classes
6. ✅ Test across all pages
7. ✅ Remove DaisyUI dependency (if going with Option A)

## Files to Update

- `/tailwind.config.mjs` - Remove DaisyUI, update colors
- `/src/styles/global.css` - Simplify and clean
- `/src/components/**/*.astro` - Update class names
- `/src/components/**/*.tsx` - Update class names
- `/package.json` - Remove daisyui dependency (optional)

## Benefits

✨ **Cleaner codebase** - One styling approach
⚡ **Better performance** - Smaller CSS bundle
🎨 **Consistent design** - No conflicting styles
🚀 **Faster development** - Clear patterns
🔧 **Easier maintenance** - Less complexity
