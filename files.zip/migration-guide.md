# Component Migration Guide

## How to Update Your Components

This guide shows how to migrate from the old DaisyUI + custom CSS to the new clean Tailwind system.

## Buttons

### Before (Old DaisyUI):
```html
<button class="btn btn-primary">Click me</button>
<button class="btn btn-secondary">Secondary</button>
<button class="btn btn-ghost">Ghost</button>
```

### After (Clean Tailwind):
```html
<button class="btn btn-personal">Click me</button>
<button class="btn btn-commons">Secondary</button>
<button class="btn btn-ghost">Ghost</button>
```

### Button Variants:
```html
<!-- Solid buttons -->
<button class="btn btn-personal">Personal Action</button>
<button class="btn btn-commons">Commons Action</button>

<!-- Outline buttons -->
<button class="btn btn-personal-outline">Outline</button>
<button class="btn btn-commons-outline">Outline</button>

<!-- Ghost buttons -->
<button class="btn btn-personal-ghost">Ghost</button>
<button class="btn btn-ghost">Neutral Ghost</button>

<!-- Semantic buttons -->
<button class="btn btn-success">Success</button>
<button class="btn btn-warning">Warning</button>
<button class="btn btn-error">Error</button>

<!-- Sizes -->
<button class="btn btn-sm btn-personal">Small</button>
<button class="btn btn-personal">Default</button>
<button class="btn btn-lg btn-personal">Large</button>
```

## Cards

### Before (Old DaisyUI):
```html
<div class="card bg-base-100 shadow-xl">
  <div class="card-body">
    <h2 class="card-title">Card Title</h2>
    <p>Card content</p>
    <div class="card-actions justify-end">
      <button class="btn btn-primary">Action</button>
    </div>
  </div>
</div>
```

### After (Clean Tailwind):
```html
<div class="card">
  <div class="card-body">
    <h2 class="card-title">Card Title</h2>
    <p>Card content</p>
    <div class="card-actions">
      <button class="btn btn-personal">Action</button>
    </div>
  </div>
</div>
```

### Card Variants:
```html
<!-- Default card -->
<div class="card">
  <div class="card-body">
    <h3 class="card-title">Standard Card</h3>
    <p>Content here</p>
  </div>
</div>

<!-- Personal workspace card -->
<div class="card card-personal">
  <div class="card-body">
    <h3 class="card-title">Personal Project</h3>
    <p>Green-themed card</p>
  </div>
</div>

<!-- Commons workspace card -->
<div class="card card-commons">
  <div class="card-body">
    <h3 class="card-title">Commons Project</h3>
    <p>Blue-themed card</p>
  </div>
</div>

<!-- With hover effect -->
<div class="card hover:shadow-lg transition-shadow cursor-pointer">
  <div class="card-body">
    <h3 class="card-title">Hoverable Card</h3>
    <p>Hover to see effect</p>
  </div>
</div>
```

## Forms

### Before (Old DaisyUI):
```html
<div class="form-control">
  <label class="label">
    <span class="label-text">Email</span>
  </label>
  <input type="email" class="input input-bordered" />
</div>
```

### After (Clean Tailwind):
```html
<div class="form-control">
  <label class="label">Email</label>
  <input type="email" class="input" placeholder="Enter your email" />
</div>
```

### Form Examples:
```html
<!-- Text input -->
<div class="form-control">
  <label class="label">Username</label>
  <input type="text" class="input" placeholder="Enter username" />
  <p class="helper-text">Choose a unique username</p>
</div>

<!-- Input with error -->
<div class="form-control">
  <label class="label">Email</label>
  <input type="email" class="input input-error" value="invalid-email" />
  <p class="error-message">Please enter a valid email address</p>
</div>

<!-- Textarea -->
<div class="form-control">
  <label class="label">Description</label>
  <textarea class="textarea" placeholder="Enter description"></textarea>
</div>

<!-- Select -->
<div class="form-control">
  <label class="label">Category</label>
  <select class="select">
    <option>Choose one</option>
    <option>Personal</option>
    <option>Commons</option>
  </select>
</div>

<!-- Checkbox -->
<div class="form-control">
  <label class="flex items-center gap-2">
    <input type="checkbox" class="checkbox" />
    <span class="label">I agree to terms</span>
  </label>
</div>

<!-- Toggle/Switch -->
<div class="form-control">
  <label class="flex items-center justify-between">
    <span class="label">Public Profile</span>
    <input type="checkbox" class="toggle" />
  </label>
</div>
```

## Badges

### Before (Old DaisyUI):
```html
<span class="badge badge-primary">Primary</span>
<span class="badge badge-secondary">Secondary</span>
```

### After (Clean Tailwind):
```html
<span class="badge badge-personal">Personal</span>
<span class="badge badge-commons">Commons</span>
<span class="badge badge-success">Active</span>
<span class="badge badge-warning">Pending</span>
<span class="badge badge-error">Error</span>
```

## Alerts

### Before (Old DaisyUI):
```html
<div class="alert alert-info">
  <span>Info message</span>
</div>
```

### After (Clean Tailwind):
```html
<div class="alert alert-info">
  <p>Info message here</p>
</div>

<!-- All variants -->
<div class="alert alert-success">✓ Success message</div>
<div class="alert alert-warning">⚠ Warning message</div>
<div class="alert alert-error">✗ Error message</div>
<div class="alert alert-info">ℹ Info message</div>
```

## Navigation

### Before (Old DaisyUI):
```html
<ul class="menu">
  <li><a>Item 1</a></li>
  <li><a class="active">Item 2</a></li>
</ul>
```

### After (Clean Tailwind):
```html
<nav>
  <a href="/dashboard" class="nav-link">Dashboard</a>
  <a href="/projects" class="nav-link nav-link-active">Projects</a>
  <a href="/settings" class="nav-link">Settings</a>
</nav>
```

## ProfileSettings.tsx Example

### Before:
```tsx
<button className="btn btn-primary" type="submit">
  Save Changes
</button>
```

### After:
```tsx
<button className="btn btn-personal" type="submit">
  Save Changes
</button>
```

### Full ProfileSettings Form Update:
```tsx
<form onSubmit={handleSubmit} className="space-y-4">
  {/* Full Name */}
  <div className="form-control">
    <label className="label">Full Name</label>
    <input
      type="text"
      placeholder="Enter your full name"
      value={fullName}
      onChange={(e) => setFullName(e.target.value)}
      className={`input ${errors.fullName ? 'input-error' : ''}`}
      maxLength={100}
    />
    {errors.fullName && (
      <p className="error-message">{errors.fullName}</p>
    )}
  </div>

  {/* Bio */}
  <div className="form-control">
    <label className="label">
      Bio
      <span className="text-sm text-gray-500">{bio.length}/500</span>
    </label>
    <textarea
      className={`textarea ${errors.bio ? 'input-error' : ''}`}
      placeholder="Tell us about yourself"
      value={bio}
      onChange={(e) => setBio(e.target.value)}
      maxLength={500}
    />
  </div>

  {/* Public Profile Toggle */}
  <div className="form-control">
    <label className="flex items-center justify-between">
      <span className="label">Public Profile</span>
      <input
        type="checkbox"
        className="toggle"
        checked={isPublic}
        onChange={(e) => setIsPublic(e.target.checked)}
      />
    </label>
    <p className="helper-text">Allow others to view your profile</p>
  </div>

  {/* Actions */}
  <div className="flex justify-end gap-3 mt-6">
    <button
      type="button"
      className="btn btn-ghost"
      onClick={handleCancel}
      disabled={isLoading}
    >
      Cancel
    </button>
    <button
      type="submit"
      className="btn btn-personal"
      disabled={isLoading}
    >
      {isLoading ? 'Saving...' : 'Save Changes'}
    </button>
  </div>
</form>
```

## DashboardLayout.astro Example

### Before:
```astro
<a href="/dashboard" 
   class={`flex items-center gap-3 px-4 py-2 rounded-lg ${isActive('/dashboard') ? 'bg-personal-primary text-white' : 'hover:bg-base-200'}`}>
  Dashboard
</a>
```

### After:
```astro
<a href="/dashboard" 
   class={`nav-link ${isActive('/dashboard') ? 'nav-link-active' : ''}`}>
  <svg class="w-5 h-5">...</svg>
  Dashboard
</a>
```

## Loading States

### Spinner:
```html
<div class="flex items-center gap-2">
  <span class="loading-spinner"></span>
  <span>Loading...</span>
</div>
```

### Skeleton:
```html
<div class="card">
  <div class="card-body space-y-3">
    <div class="skeleton h-6 w-3/4"></div>
    <div class="skeleton h-4 w-full"></div>
    <div class="skeleton h-4 w-full"></div>
    <div class="skeleton h-4 w-2/3"></div>
  </div>
</div>
```

## Dark Mode Support

All components automatically support dark mode when you use `data-theme="dark"`:

```html
<html data-theme="dark">
  <!-- All components now use dark mode styles -->
</html>
```

## Quick Reference: Class Names Changed

| Old (DaisyUI) | New (Clean Tailwind) |
|---------------|----------------------|
| `btn-primary` | `btn-personal` or `btn-commons` |
| `btn-secondary` | `btn-commons` or `btn-neutral` |
| `bg-base-100` | `bg-white` or use card class |
| `bg-base-200` | `bg-gray-50` |
| `text-base-content` | `text-gray-900` |
| `input-bordered` | `input` (border included) |
| `badge-primary` | `badge-personal` |
| `alert-info` | `alert-info` (same!) |

## Tips for Migration

1. **Search and replace** common patterns in your codebase
2. **Test each component** after updating
3. **Keep old classes temporarily** - comment them out first
4. **Update one file at a time** to avoid breaking everything
5. **Check dark mode** for each updated component

## Need Help?

If a component doesn't work as expected:
1. Check if you're using the right class names
2. Make sure `global.clean.css` is imported
3. Verify `tailwind.config.clean.mjs` is being used
4. Test in both light and dark mode
