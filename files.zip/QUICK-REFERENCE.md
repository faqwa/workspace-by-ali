# Quick Reference Card - New Component Classes

## 🚀 Most Common Classes You'll Use

### Buttons
```html
<!-- Primary actions -->
<button class="btn btn-personal">Personal Action</button>
<button class="btn btn-commons">Commons Action</button>

<!-- Secondary actions -->
<button class="btn btn-personal-outline">Outline</button>
<button class="btn btn-ghost">Cancel</button>

<!-- Sizes -->
<button class="btn btn-sm btn-personal">Small</button>
<button class="btn btn-lg btn-personal">Large</button>

<!-- States -->
<button class="btn btn-personal" disabled>Disabled</button>
```

### Cards
```html
<!-- Basic card -->
<div class="card">
  <div class="card-body">
    <h3 class="card-title">Title</h3>
    <p>Content goes here</p>
    <div class="card-actions">
      <button class="btn btn-personal">Action</button>
    </div>
  </div>
</div>

<!-- Themed cards -->
<div class="card card-personal">Personal themed</div>
<div class="card card-commons">Commons themed</div>
```

### Forms
```html
<!-- Text input -->
<div class="form-control">
  <label class="label">Label</label>
  <input type="text" class="input" placeholder="Placeholder" />
</div>

<!-- With error -->
<div class="form-control">
  <label class="label">Email</label>
  <input type="email" class="input input-error" />
  <p class="error-message">Error message here</p>
</div>

<!-- Textarea -->
<textarea class="textarea" placeholder="Enter text"></textarea>

<!-- Select -->
<select class="select">
  <option>Choose one</option>
</select>

<!-- Checkbox -->
<input type="checkbox" class="checkbox" />

<!-- Toggle -->
<input type="checkbox" class="toggle" />
```

### Badges
```html
<span class="badge badge-personal">Personal</span>
<span class="badge badge-commons">Commons</span>
<span class="badge badge-success">Success</span>
<span class="badge badge-warning">Warning</span>
<span class="badge badge-error">Error</span>
```

### Alerts
```html
<div class="alert alert-success">Success message</div>
<div class="alert alert-warning">Warning message</div>
<div class="alert alert-error">Error message</div>
<div class="alert alert-info">Info message</div>
```

### Navigation
```html
<a href="/dashboard" class="nav-link">Dashboard</a>
<a href="/projects" class="nav-link nav-link-active">Projects</a>
```

### Utilities
```html
<!-- Container -->
<div class="container-custom">Content</div>

<!-- Loading spinner -->
<span class="loading-spinner"></span>

<!-- Skeleton loader -->
<div class="skeleton h-6 w-full"></div>

<!-- Divider -->
<div class="divider"></div>
```

## 🎨 Color Classes

### Backgrounds
- `bg-personal-500` - Personal primary
- `bg-commons-500` - Commons primary
- `bg-green-500` - Success
- `bg-amber-500` - Warning
- `bg-red-500` - Error

### Text
- `text-personal-600` - Personal text
- `text-commons-600` - Commons text
- `text-gray-900` - Primary text
- `text-gray-600` - Secondary text

### Borders
- `border-personal-500` - Personal border
- `border-commons-500` - Commons border
- `border-gray-300` - Default border

## 📱 Responsive Modifiers

```html
<!-- Mobile first approach -->
<div class="p-4 md:p-6 lg:p-8">
  <!-- 4 on mobile, 6 on tablet, 8 on desktop -->
</div>

<div class="text-base md:text-lg lg:text-xl">
  <!-- Larger text on bigger screens -->
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
  <!-- 1 column mobile, 2 tablet, 3 desktop -->
</div>
```

## 🌙 Dark Mode

Add `[data-theme="dark"]` to html element:
```html
<html data-theme="dark">
```

All components automatically adapt!

## 🔄 Search & Replace

Quick fixes for your codebase:

### Find → Replace
- `btn-primary` → `btn-personal`
- `btn-secondary` → `btn-commons`
- `bg-base-100` → `bg-white` or use `card` class
- `bg-base-200` → `bg-gray-50`
- `input-bordered` → `input`
- `badge-primary` → `badge-personal`
- `text-base-content` → `text-gray-900`

## ⚡ Pro Tips

1. **Use consistent spacing**: `space-y-4` for vertical, `gap-4` for flex/grid
2. **Combine classes**: `btn btn-sm btn-personal` works great
3. **Dark mode**: All components support it automatically
4. **Hover states**: Most interactive elements have built-in hover
5. **Focus states**: Keyboard navigation is included

## 📐 Common Layouts

### Two Column
```html
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
  <div>Left</div>
  <div>Right</div>
</div>
```

### Three Column
```html
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  <div>1</div>
  <div>2</div>
  <div>3</div>
</div>
```

### Centered Content
```html
<div class="flex items-center justify-center min-h-screen">
  <div class="w-full max-w-md">
    <!-- Your content -->
  </div>
</div>
```

### Sidebar + Content
```html
<div class="flex min-h-screen">
  <aside class="w-64 bg-gray-50">Sidebar</aside>
  <main class="flex-1 p-6">Content</main>
</div>
```

## 💡 Remember

- **Mobile first**: Start with mobile, add responsive classes
- **Semantic colors**: Use personal/commons for branded, green/red for semantic
- **Consistent spacing**: Stick to 4, 8, 16, 24, 32, 48px (Tailwind spacing)
- **Dark mode**: Test everything in both themes
- **Accessibility**: Use semantic HTML and ARIA when needed

---

**Keep this handy while migrating!** 🎯
