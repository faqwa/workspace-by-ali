# Complete Design System Integration Plan
## Using ALL Your Improved Designs to Lead the Website

You have **3 beautiful, modern HTML designs** that should become your website's foundation:

1. **projects-page-redesign.html** - Modern dashboard with stats, cards, filters
2. **create-project-redesign.html** - Clean form design with visibility toggles
3. **custom-markdown-editor.html** - ⭐ **GORGEOUS** editor with live preview, templates, toolbar

## 🎯 Vision: A Unified, Modern Design System

All three designs share:
- ✅ **Same green primary** (#00D084)
- ✅ **Consistent typography** (system fonts, clean hierarchy)
- ✅ **Modern spacing** (generous whitespace)
- ✅ **Smooth animations** (hover effects, transitions)
- ✅ **Professional polish** (rounded corners, subtle shadows)

### The Big Idea

These designs aren't just mockups - they're a **complete design language**. Let's extract and systematize them into:

1. **Core Design System** - Colors, typography, spacing, shadows
2. **Component Library** - Buttons, cards, forms, editor
3. **Page Templates** - Dashboard, editor, forms
4. **Interactive Patterns** - Modals, toggles, live preview

## Phase 1: Extract the Markdown Editor Design System

The markdown editor is your **crown jewel** - it shows the most sophisticated patterns:

### Components from Markdown Editor:

#### 1. **Header Bar** (Top navigation)
```css
.editor-header {
  background: white;
  border-bottom: 1px solid #E5E7EB;
  padding: 12px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* Back button */
.back-btn {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: #6B7280;
  cursor: pointer;
  transition: all 0.2s;
}

.back-btn:hover {
  background: #F3F4F6;
}

/* Document title input */
.doc-title-input {
  border: none;
  font-size: 16px;
  font-weight: 600;
  color: #111827;
  padding: 8px 16px;
  border-radius: 6px;
  transition: background 0.2s;
}

.doc-title-input:hover {
  background: #F3F4F6;
}

.doc-title-input:focus {
  outline: none;
  background: #F3F4F6;
}
```

#### 2. **View Toggle** (Edit/Split/Preview)
```css
.view-toggle {
  display: flex;
  background: #F3F4F6;
  border-radius: 8px;
  padding: 4px;
  gap: 4px;
}

.view-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border-radius: 6px;
  border: none;
  background: transparent;
  color: #6B7280;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.view-btn.active {
  background: white;
  color: #111827;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}
```

#### 3. **Toolbar** (Formatting buttons)
```css
.editor-toolbar {
  background: white;
  border-bottom: 1px solid #E5E7EB;
  padding: 8px 24px;
  display: flex;
  gap: 16px;
  overflow-x: auto;
}

.toolbar-group {
  display: flex;
  gap: 4px;
  padding: 0 12px;
  border-right: 1px solid #E5E7EB;
}

.toolbar-group:last-child {
  border-right: none;
}

.toolbar-btn {
  width: 32px;
  height: 32px;
  padding: 6px;
  border-radius: 6px;
  border: none;
  background: transparent;
  color: #6B7280;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.toolbar-btn:hover {
  background: #F3F4F6;
  color: #111827;
}

.toolbar-btn.active {
  background: #E6F9F3;
  color: #00A368;
}
```

#### 4. **Sidebar** (Outline/Recent)
```css
.editor-sidebar {
  width: 260px;
  background: white;
  border-right: 1px solid #E5E7EB;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.sidebar-section {
  padding: 20px;
  border-bottom: 1px solid #E5E7EB;
}

.sidebar-title {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #6B7280;
  margin-bottom: 12px;
}

.sidebar-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 14px;
  color: #6B7280;
}

.sidebar-item:hover {
  background: #F3F4F6;
  color: #111827;
}

.sidebar-item.active {
  background: #E6F9F3;
  color: #00A368;
}
```

#### 5. **Split Pane Layout** (Editor + Preview)
```css
.editor-content {
  flex: 1;
  display: flex;
  position: relative;
}

.editor-pane {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: white;
}

.pane-divider {
  width: 4px;
  background: #E5E7EB;
  cursor: col-resize;
  transition: background 0.2s;
}

.pane-divider:hover {
  background: #00D084;
}
```

#### 6. **Markdown Text Area**
```css
.editor-textarea {
  flex: 1;
  border: none;
  padding: 24px;
  font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Roboto Mono', Consolas, monospace;
  font-size: 14px;
  line-height: 1.8;
  color: #111827;
  resize: none;
  background: white;
}

.editor-textarea:focus {
  outline: none;
}
```

#### 7. **Preview Pane** (Rendered markdown)
```css
.preview-pane {
  padding: 24px;
  overflow-y: auto;
  line-height: 1.8;
}

.preview-pane h1 {
  font-size: 32px;
  font-weight: 700;
  margin-top: 32px;
  margin-bottom: 16px;
  color: #111827;
}

.preview-pane blockquote {
  border-left: 4px solid #00D084;
  padding-left: 16px;
  margin: 16px 0;
  color: #6B7280;
  font-style: italic;
}

/* And all other markdown styles... */
```

#### 8. **Footer Stats** (Word count, character count)
```css
.editor-footer {
  background: white;
  border-top: 1px solid #E5E7EB;
  padding: 8px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  color: #6B7280;
}

.footer-stats {
  display: flex;
  gap: 24px;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 6px;
}
```

#### 9. **Template Modal** (Insert template)
```css
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.3s;
  z-index: 1000;
}

.modal-overlay.active {
  opacity: 1;
  pointer-events: all;
}

.modal {
  background: white;
  border-radius: 16px;
  max-width: 800px;
  width: 90%;
  max-height: 80vh;
  overflow: hidden;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
}

.template-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 16px;
  padding: 24px;
}

.template-card {
  background: white;
  border: 1.5px solid #E5E7EB;
  border-radius: 12px;
  padding: 20px;
  cursor: pointer;
  transition: all 0.2s;
}

.template-card:hover {
  border-color: #00D084;
  box-shadow: 0 4px 12px rgba(0, 208, 132, 0.1);
  transform: translateY(-2px);
}
```

#### 10. **Templates** (Research note, Experiment, etc.)

The editor includes fantastic templates:
- **Research Note** - Document findings and insights
- **Experiment Log** - Track hypothesis, methods, results
- **Literature Review** - Analyze research papers
- **Meeting Notes** - Capture discussions and action items
- **Weekly Update** - Share progress and learnings

These templates should be available in your CMS!

## Phase 2: Unified Component System

Create `/src/components/design-system/` with components:

```
/src/components/design-system/
├── Button/
│   ├── Button.astro
│   ├── ActionButton.astro
│   └── ToolbarButton.astro
├── Card/
│   ├── Card.astro
│   ├── ProjectCard.astro
│   ├── StatCard.astro
│   └── TemplateCard.astro
├── Form/
│   ├── Input.astro
│   ├── Textarea.astro
│   ├── Select.astro
│   └── VisibilityToggle.astro
├── Editor/
│   ├── MarkdownEditor.astro
│   ├── Toolbar.astro
│   ├── Preview.astro
│   └── TemplateModal.astro
├── Navigation/
│   ├── Sidebar.astro
│   ├── Header.astro
│   └── ViewToggle.astro
└── Layout/
    ├── SplitPane.astro
    ├── PageHeader.astro
    └── Footer.astro
```

## Phase 3: Page Implementation Plan

### 1. **Dashboard** (Use projects-page-redesign.html)
- Stats cards showing project counts
- Search and filter bar
- Project grid with cards
- Sidebar navigation

### 2. **Create Project** (Use create-project-redesign.html)
- Clean form layout
- Visibility toggle component
- Character counters
- Form validation

### 3. **Editor** (Use custom-markdown-editor.html) ⭐
- **Full markdown editor with:**
  - Live preview
  - Formatting toolbar
  - Template insertion
  - Outline sidebar
  - Word/character count
  - Keyboard shortcuts

### 4. **Updates List**
- Reuse project card style
- Filter by tags/status
- Search functionality

## Phase 4: Implementation Timeline

### Week 1: Foundation (16 hours)
**Day 1-2: Design System Setup**
- Extract all CSS from HTML files
- Create design-system.css with all patterns
- Update Tailwind config with exact colors
- Test with one page

**Day 3-4: Core Components**
- Build Button components (3 types)
- Build Card components (3 types)
- Build Form components (4 types)
- Test responsiveness

**Day 5: Documentation**
- Component documentation
- Usage examples
- Storybook/preview page

### Week 2: Pages (20 hours)
**Day 1-2: Dashboard**
- Implement page header
- Build stats row
- Create project grid
- Add search/filter

**Day 3: Create Project**
- Build form layout
- Implement visibility toggle
- Add validation
- Test submission

**Day 4-5: Markdown Editor** ⭐
- Build editor layout
- Implement toolbar
- Add live preview
- Create template system
- Add keyboard shortcuts

### Week 3: Polish (12 hours)
**Day 1: Integration**
- Connect all pages
- Test navigation
- Fix responsive issues

**Day 2: Templates**
- Research Note template
- Experiment Log template
- Meeting Notes template
- Weekly Update template

**Day 3: Testing & QA**
- Cross-browser testing
- Mobile testing
- Accessibility audit
- Performance check

## Phase 5: Priority Features from Markdown Editor

### Must-Have Features:
1. ✅ **Live Preview** - Split/edit/preview modes
2. ✅ **Formatting Toolbar** - Bold, italic, headings, lists, etc.
3. ✅ **Templates** - Pre-built content structures
4. ✅ **Auto-save** - Never lose work
5. ✅ **Word Count** - Writing stats
6. ✅ **Outline** - Document structure navigation

### Nice-to-Have:
- Keyboard shortcuts (Cmd+B for bold, etc.)
- Fullscreen mode
- Export to PDF
- Collaborative editing
- Version history

## Files to Create

### 1. Complete Design System CSS
`/src/styles/design-system-complete.css` - All patterns from all 3 designs

### 2. Markdown Editor Component
`/src/components/MarkdownEditor.astro` - Full featured editor

### 3. Template System
`/src/lib/templates.ts` - All markdown templates

### 4. Updated Pages
- `/src/pages/dashboard.astro`
- `/src/pages/projects.astro`
- `/src/pages/projects/create.astro`
- `/src/pages/updates/create.astro` (with editor!)
- `/src/pages/updates/[slug]/edit.astro` (with editor!)

## Key Technologies

### For Markdown Editor:
- **marked.js** or **markdown-it** - Markdown parsing
- **CodeMirror** or keep textarea - Editor enhancements (optional)
- **Prism.js** - Code syntax highlighting
- **localStorage** - Auto-save drafts

### Integration:
```typescript
// Example: Markdown Editor Component
import { marked } from 'marked';
import { useState, useEffect } from 'react';

const MarkdownEditor = () => {
  const [content, setContent] = useState('');
  const [preview, setPreview] = useState('');
  
  useEffect(() => {
    setPreview(marked(content));
  }, [content]);
  
  // Auto-save
  useEffect(() => {
    const timer = setTimeout(() => {
      localStorage.setItem('draft', content);
    }, 1000);
    return () => clearTimeout(timer);
  }, [content]);
  
  return (
    <div class="editor-content">
      <div class="editor-pane">
        <textarea 
          value={content}
          onChange={(e) => setContent(e.target.value)}
          class="editor-textarea"
        />
      </div>
      <div class="preview-pane">
        <div dangerouslySetInnerHTML={{ __html: preview }} />
      </div>
    </div>
  );
};
```

## Success Criteria

You'll know the integration is successful when:

✅ All pages use the same design language
✅ Components are reusable and consistent
✅ Markdown editor works flawlessly
✅ Templates insert correctly
✅ Live preview updates in real-time
✅ Mobile responsive across all views
✅ Fast performance (no lag when typing)
✅ Professional, polished appearance
✅ Users love writing updates!

## Next Steps

1. **Review this plan** - Does it capture your vision?
2. **Start with design system** - Extract all CSS
3. **Build core components** - Button, Card, Form first
4. **Implement markdown editor** - The star of the show!
5. **Apply to all pages** - Consistent experience

## Why This is Exciting 🎉

Your custom markdown editor is **professional grade**:
- Clean, distraction-free writing
- Live preview for instant feedback
- Templates for structure
- Professional toolbar
- Beautiful typography

Combined with your dashboard and form designs, you have a **complete, modern design system** that will make your app stand out!

Ready to build the best research workspace ever! 🚀
